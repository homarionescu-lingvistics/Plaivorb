<sub>[← Cuprins](./README.md)</sub>

---

## 4. Metodologia computațională și critica filiațiilor

> **Document-sursă integrat integral:** `Dialectica Dogmei și a Datelor: P-Hacking Computațional, Tipologie Structurală și Arbitrariul Filiațiilor în Lingvistica Istorică`
> Conținutul de mai jos este inclus ca material documentar; eventualele afirmații istorice, etimologice sau geopolitice rămân supuse verificării critice.

Capitolul 1: Cazul Românesc — Fragilitatea Corespondențelor Fonetice și Supraviețuirea Substratului
Istoriografia lingvisticii istorice europene reflectă o luptă constantă între analiza științifică empirică și proiectele geopolitice de consolidare a identităților naționale<sup>1</sup>. Pe parcursul secolelor al XIX-lea și al XX-lea, modelele arborescente genealogice au fost utilizate frecvent de filologii afiliați curentelor statale pentru a argumenta puritatea culturală și continuitatea neîntreruptă a unor populații direct din surse imperiale de prestigiu, cum ar fi Imperiul Roman<sup>1</sup>. În spațiul românesc, Școala Ardeleană și succesorii săi din secolul al XIX-lea au recurs la un purism etimologic sistematic și la înlocuirea alfabetului chirilic cu cel latin pentru a demonstra descendența directă și pură din coloniștii lui Traian<sup>1</sup>. Acest demers a generat ulterior o reacție critică din partea unor intelectuali precum Bogdan Petriceicu Hasdeu și Ion Heliade Rădulescu, care au combătut purificarea artificială a limbii și au atras atenția asupra importanței uzului viu și a elementelor indigene<sup>1</sup>.
Din perspectivă metodologică, lingvistica istorică tradițională s-a bazat în mod disproporționat pe stabilirea de corespondențe fonetice sistematice la nivelul lexicului de bază<sup>1</sup>. Totuși, abordările computaționale moderne demonstrează că această practică este vulnerabilă la un fenomen similar manipulării datelor statistice în științele experimentale, cunoscut sub numele de p-hacking<sup>1</sup>. Lingviștii tradiționali aleg adesea „pe sprânceană” exclusiv cuvintele care se potrivesc cu regulile fonetice preconcepute (cum sunt cele incluse în listele Swadesh) și ignoră în mod sistematic datele problematice, anomaliile și lexicul recalcitrant care contrazic arborele genealogic asumat<sup>1</sup>. Această selecție părtinitoare distorsionează realitatea evoluției lingvistice, transformând corespondențele fonetice într-un instrument extrem de maleabil<sup>1</sup>.
Mecanismul de Filtrare Vocală a Substratului: Cazul Aqua-Apă
Spre deosebire de narațiunea simplificată a romanizării complete și a asimilării genetice a populației locale, analiza structurală și fonetică indică existența unui proces profund de hibridizare<sup>1</sup>. Un argument central adus de lingviștii tradiționali în favoarea latinității exclusive a limbii române este evoluția regulată a labiovelarelor latine către consoane bilabiale<sup>1</sup>. Se afirmă adesea că transformări precum latinul aqua în românescul apă, noctem în noapte sau quattuor în patru constituie dovezi matematice incontestabile ale descendenței directe din latina vulgară<sup>1</sup>.
Această interpretare omite însă un mecanism sociolingvistic fundamental<sup>1</sup>. Datele nu indică faptul că vorbitorii autohtoni din Dacia posedau deja în mod nativ cuvântul apă dintr-o fază anterioară a Proto-Indo-Europenei (PIE)<sup>1</sup>. Din contră, populația indigenă a preluat în mod activ cuvântul latin sosit ca împrumut în comunitate (incoming Latin loanword), respectiv aqua<sup>1</sup>. Însă, în momentul în care populația indigenă (autohtonă) a auzit cuvântul aqua, aparatul lor vocal nativ—care era deja configurat istoric printr-o regulă PIE de a transforma velarele și labiovelarele în labiale—a acționat ca un filtru fonetic automat<sup>1</sup>. Această regulă de transformare este reprezentată prin ecuația:

Prin urmare, deformarea cuvântului aqua în apă nu s-a produs pentru că vorbitorii erau romani puri sau pentru că au adoptat pasiv fonetica latină, ci pentru că aparatul vocal al dacilor a deformat în mod activ și automat împrumutul latin după propriile reguli fonetice moștenite genealogic din PIE<sup>1</sup>. Când lingviștii tradiționali exclamă: „Priviți, aqua a devenit apă, noctem a devenit noapte, quattuor a devenit patru, deci regulile fonetice demonstrează că suntem romani!”, modelul matematic și lingvistic demonstrează că transformarea acestor cuvinte poate fi, de fapt, dovada supraviețuirii limbii dace (a substratului)<sup>1</sup>. Acest fenomen confirmă un principiu teoretic major: corespondența fonetică poate reflecta păstrarea obiceiurilor fonetice ale unui substrat nativ la fel de ușor cum poate reflecta o moștenire genetică directă și nehibridizată<sup>1</sup>.
Fragilitatea Regulilor Fonetice și Flexibilizarea Parametrilor Algoritmici
Dacă algoritmul computațional utilizat pentru a evalua distanțele lingvistice pe baza claselor de sunete (cum sunt cele din standardul ASJP) este modificat pentru a deveni mult mai flexibil, capacitatea sa de a distinge filiațiile genetice reale se prăbușește<sup>1</sup>. Atunci când costul de tranziție între velare și labiale () este setat la o valoare foarte mică sau considerat extrem de probabil, computerul începe să identifice tipare similare între limbi complet neînrudite, generând corelații false<sup>1</sup>.
Prin ajustarea parametrică a costurilor de substituție în cadrul algoritmului Levenshtein ponderat fonetic, se poate argumenta cu o rigoare aparentă că limba română s-ar trage din lituaniană, albaneză, celtică, slavă sau chiar din indoneziană<sup>1</sup>. Această flexibilizare artificială a regulilor arată că simpla corespondență fonetică nu garantează o filiație genetică exclusivă sau directă din latină, ci constituie adesea un artefact al calibrării parametrilor algoritmului<sup>1</sup>.
 • Argumentarea filiației baltice (Lituaniană): Prin reducerea penalizării pentru tranziția dintre velare și labiale, românescul apă se aliniază optim cu lituanianul upė („râu”), derivat din aceeași rădăcină PIe *h₂ep-3. De asemenea, perechea patru keturi obține o distanță de editare extrem de scăzută () și o proximitate ridicată ()3, permițând unui model nesupravegheat să asocieze româna cu ramura baltică pe baza conservării structurilor satem tardive<sup>2</sup>.
 • Argumentarea filiației balkanice (Albaneză): Structuri lexicale precum vatră vatër3 sau sat (derivat în mod controversat din fossatum sau dintr-o rădăcină autohtonă necunoscută)1 demonstrează o convergență fonetică strânsă ( proximitate pentru vatră/vatër)<sup>3</sup>. Aceasta indică existența unui substrat comun paleo-balkanic mai degrabă decât o imigrare medievală la sud de Dunăre, așa cum susținea teoria roesleriană<sup>1</sup>.
 • Argumentarea filiației celtice: Multe elemente considerate latine în română prezintă de fapt o influență celtică prealabilă expansiunii romane<sup>1</sup>. De exemplu, verbele a încăleca / a descăleca (derivate oficial din caballicare) provin dintr-o rădăcină legată de cal, împrumutată de latini de la celți înainte de anul 106 AD<sup>1</sup>. De asemenea, transformarea PIE a labiovelarelor în bilabiale () este o trăsătură definitorie a dialectelor celtice de tip P (P-Celtic), exact ca în cazul substratului dacic, sugerând o afiliație structurală strânsă între cele două ramuri<sup>2</sup>.
 • Argumentarea filiației slavice: Semantic și fonetic, cuvinte precum oaste (derivat din latinul hostis, care însemna inițial „dușman” în latina clasică) reflectă o evoluție în care forțele armate erau percepute exclusiv ca invadatori străini<sup>1</sup>. O evoluție similară a rădăcinii se regăsește în sârbocroată și albaneză1, permițând algoritmului să asocieze evoluția semantică a românei cu modelul slav de organizare militară medievală<sup>1</sup>.
 • Demonstrația filiației indoneziene (Austroneziană): Cazul cel mai extrem de coincidență fonetică validat de un algoritm prea flexibil este cel al limbii indoneziene<sup>1</sup>. Rularea algoritmului pe termeni selectați relevă aliniamente fonetice perfecte sau aproape perfecte, complet independente de orice contact istoric<sup>3</sup>. Românescul apă este identic cu indonezianul apa („ce/ceea ce”), generând un cost de și o proximitate de 3. Falsele cognate moarte / muri comparate cu indonezianul mati („mort/a muri”)3, doi cu dua („doi”)3, punte cu pintu („ușă”)3 și babe cu babi („porc”)3 obțin scoruri de proximitate extrem de ridicate, dovedind că o potrivire statistică nu implică o legătură genetică<sup>1</sup>.

Lexem Română
Lexem Sursă Comparat
Limba Sursă
Semnificație Sursă
Cost Editare (Standard)
Cost Editare (Flexibil)
Proximitate Fonetică Flexibilă
Tipul de Relație Evidențiat de Algoritm
apă
apa
Indoneziană
ce / ce anume
0.00
0.00
1.003
Coincidență homofonică absolută (Fals prieten)<sup>7</sup>.
muri
mati
Indoneziană
a muri
2.40
1.20
0.623
Similitudine pur accidentală de tip consoană-vocală<sup>7</sup>.
doi
dua
Indoneziană
doi
1.60
0.40
0.833
Pseudocognat austronezian nesusținut istoric<sup>7</sup>.
punte
pintu
Indoneziană
ușă
2.40
0.40
0.903
Corelare artificială obținută prin relaxarea nazalelor.
babe
babi
Indoneziană
porc
1.60
0.20
0.943
Aliniere generată de costul redus al alternanțelor vocalice.
apă
upė
Lituaniană
râu
1.60
0.40
0.833
Conservare paralelă din rădăcina PIE *h₂ep-4.
patru
keturi
Lituaniană
patru
3.20
1.50
0.693
Corespondență bazată pe evoluția divergentă a labiovelarei<sup>5</sup>.
noapte
naktis
Lituaniană
noapte
3.60
2.10
0.563
Evoluție fonetică paralelă în ramura baltică satem<sup>5</sup>.
vatră
vatër
Albaneză
vatră
2.00
1.60
0.603
Element lexical partajat din substratul comun balkanic<sup>8</sup>.
Limitele Relevanței Fonetice în Absența Dovezilor Scrise
Toate aceste exemple converg către o concluzie epistemologică crucială: analiza corespondențelor fonetice realizată izolat nu are nicio relevanță diagnostică pentru asocierea unei limbi cu o anumită ramură genetică în lipsa dovezilor scrise directe<sup>1</sup>. Atât celta continentală în cazul limbii franceze9, cât și limba dacică în cazul limbii române4 sunt limbi extrem de slab atestate în scris, supraviețuind aproape exclusiv prin intermediul numelor de locuri, de persoane sau al gloselor izolate<sup>1</sup>. Această penurie de documente scrise directe permite construirea de teorii contradictorii și favorizează apariția p-hackingului academic<sup>1</sup>.
O demonstrație clară a modului în care atestările scrise pot demonta asocierile fonetice eronate este oferită de situația din nordul Africii, în special în Tunisia<sup>1</sup>. În araba tunisiană, există o serie de rădăcini lexicale și structuri morfologice care par, la o primă analiză fonetică, a fi de origine punică (limba semitică vorbită în Cartagina antică, înrudită cu araba)<sup>1</sup>. Deoarece ambele limbi sunt semitice și partajează rădăcini triconsonantice similare, mulți cercetători au emis ipoteze cu privire la supraviețuirea unui substrat punic masiv în dialectele de tip pre-hilalian<sup>11</sup>.
Cu toate acestea, prezența unui corpus bogat de scrieri în limba berberă (tamazight), atestat încă din antichitate prin intermediul alfabetului Libyco-Berber și al scrierii Tifinagh11, oferă dovezile scrise necesare pentru a demonstra că aceste presupuse rădăcini punice sunt, de fapt, împrumuturi din berberă<sup>1</sup>.
 • Termenul tunisian məlɣiɣa („fontanelă”) este atestat direct ca provenind din berberul tamelɣiɣt, neavând nicio legătură cu araba clasică sau punicul<sup>15</sup>.
 • Cuvântul bəkkuš („mut/surd-mut”), atribuit adesea unui substrat semitic antic, este în realitate o adaptare expresivă a cuvântului arab *'abkam, la care s-a adăugat sufixul productiv de origine berberă -uš15.
 • Cuvântul pentru broască țestoasă, fakrūn, provine din rădăcina berberă ifker/ikfer, integrată ulterior în fonologia arabă prin intermediul sufixului augmentativ -ūn<sup>16</sup>.
Atestările scrise berbere permit lingviștilor să identifice cu exactitate originea acestor termeni și să respingă speculațiile bazate exclusiv pe asemănări fonetice de tip punic<sup>12</sup>. În lipsa unor documente scrise similare pentru dacică sau pentru celta continentală, încercările de a separa moștenirea genetică directă de influența substratului rămân în mod inevitabil ambigue și vulnerabile la manipularea datelor<sup>1</sup>.
Morfosintaxa ca Sistem de Operare al Limbii
În timp ce lexicul reprezintă adstratul cel mai vizibil și cel mai ușor de manipulat de către elitele politice interesate de asimilarea unor modele de prestigiu cultural1, structura gramaticală profundă a unei limbi (sistemul de operare) este mult mai stabilă și rezistentă la schimbări rapide<sup>1</sup>.
O analiză cantitativă bazată pe calculul distanței Manhattan normalizate () pe un set de 12 parametri morfosintactici definitorii relevă o realitate structurală complet diferită de cea sugerată de lexicul de origine latină<sup>1</sup>. Acești parametri includ utilizarea articolului enclitic, înlocuirea infinitivului în structurile verbale, viitorul format cu verbul „a vrea”, identitatea cazurilor genitiv și dativ, precum și numeralele de la 11 la 19 construite după șablonul „peste zece”<sup>1</sup>.
Parametru Morfosintactic Evaluat
Română
Albaneză
Bulgară
Latină
Franceză
Articol hotărât enclitic
1
1
1
0
0
Înlocuirea infinitivului
1
1
1
0
0
Viitor cu verbul auxiliar „a vrea”
1
1
1
0
0
Sincretismul cazurilor Genitiv-Dativ
1
1
0
0
0
Vocativ marcat prin sufixul „-o”
1
1
1
0
0
Pronume posesiv antepus
0
0
0
1
1
Reduplicare clitică (dublarea pronumelor)
1
1
1
0
0
Numerale 11-19 construite ca „peste zece”
1
1
1
0
0
Prepoziția „la” utilizată pentru Acuzativ
1
0
1
0
0
Sufixul derivativ „-mânt”
0
1
0
0
0
Absența neutrului morfologic pur
1
1
1
0
0
Sincretismul cazurilor Locativ-Ablativ
1
1
1
0
0
Distanțele Manhattan normalizate rezultate din această matrice relevă o convergență structurală masivă a limbii române cu limbile din Uniunea Lingvistică Balcanică (Sprachbund) și o divergență totală față de latina clasică și limbile romanice occidentale:

Aceste rezultate matematice demonstrează că, deși româna posedă un adstrat lexical latin foarte vizibil și de prestigiu, motorul său gramatical profund a fost restructurat complet prin contactul prelungit cu limbile balcanice, conservând în același timp deprinderile morfosintactice și fonetice ale substratului autohton<sup>1</sup>.
Capitolul 2: P-Hacking în Reconstrucția Proto-Indo-Europene (PIE) și a Limbilor Proto-Germanice
Tensiunile metodologice dintre dovezile empirice și narațiunile idealizate de puritate lingvistică nu sunt specifice doar spațiului est-european, ci marchează profund și reconstrucția Proto-Indo-Europenei (PIE) și a limbilor proto-germanice<sup>1</sup>. În secolul al XIX-lea, filologii germani au promovat intens conceptul de Indogermanisch (Indo-Germanic), poziționând limbile germanice în centrul simbolic al acestei familii și construind mitul unei migrații ariene pure din stepele pontice care ar fi înlocuit complet populațiile neolitice locale<sup>1</sup>.
Pentru a susține acest model al purității genetice și lingvistice, etimologii tradiționali au recurs frecvent la supra-ajustarea modelelor (overfitting) și la asocieri semantice forțate, ignorând faptul că aproximativ o treime din vocabularul comun germanic nu prezintă cognate în alte limbi indo-europene<sup>1</sup>. Acest vocabular non-indo-european—analizat în cadrul Hipotezei Substratului Germanic de John Hawkins, Guus Kroonen și Aljoša Šorgo—este legat de domenii precum ecologia marină, agricultura nordică și terminologia socială locală, reflectând o asimilare masivă a populațiilor neolitice din culturile Funnelbeaker și Pitted Ware de către migratorii Corded Ware<sup>1</sup>.
Mecanica Arbitrariului în Teoria Laringeală și Glotalică
În încercarea de a demonstra că întregul vocabular proto-germanic provine din PIE, lingviștii tradiționali au recurs la adăugarea sistematică de elemente abstracte în rădăcinile PIE reconstituite, proces ce reprezintă o formă avansată de p-hacking academic<sup>1</sup>. Cele mai eficiente instrumente utilizate în acest scop sunt laringealele () și consoanele glotalice/ejective ()<sup>19</sup>.
Teoria laringeală postulează că PIE poseda o serie de consoane fricative speciale care s-au pierdut în toate ramurile cu excepția celei anatoliene (Hittite), influențând însă vocalele adiacente prin colorare și alungire compensatorie<sup>19</sup>. Din punct de vedere computațional, aceste laringeale funcționează ca variabile libere sau wildcards<sup>3</sup>. Atunci când o rădăcină germanică prezintă un vocalism neregulat care nu corespunde legilor fonetice standard, lingvisticienii pot „reconstrui” ad-hoc o laringeală în poziția dorită, explicând anomalia prin dispariția ulterioară a acesteia fără a lăsa urme fizice<sup>22</sup>.
Acest model introduce o ambiguitate inerentă, criticată dur de savanți precum Oswald Szemerényi, care a argumentat că versiunile hibride ale teoriei (care folosesc trei sau mai multe laringeale, cum sunt modelele lui Kortlandt sau Rix) permit explicarea oricărui vocalism prin intermediul ambelor opțiuni: fie o laringeală, fie o vocală primară din sistemul neogramatic<sup>22</sup>. Această dublă fixare face ca reconstrucțiile să fie practic imposibil de infirmat (unfalsifiable)<sup>22</sup>. Szemerényi a propus simplificarea radicală a cadrului teoretic prin adoptarea monolaringealismului (o singură fricativă glotală corespunzătoare hittitului ḫ)<sup>22</sup>.
În mod similar, Teoria Glotalică reinterpretează ocluzivele sonore din PIE ca ejective<sup>20</sup>. Deși rezolvă anomalia lipsei labialei sonore , utilizarea ejectivei permite lingviștilor să eludeze restricțiile structurale ale rădăcinilor (cum este interdicția apariției a două ocluzive sonore în aceeași rădăcină, de tipul *deg-)<sup>20</sup>. Prin redefinirea lor ca glotalice, aceste rădăcini sunt acceptate și conectate arbitrar la vocabularul germanic<sup>20</sup>.
Studiul de Caz: Vocabularul Substratului Germanic
Pentru a evidenția p-hackingul metodologic, se pot analiza etimologiile propuse pentru termeni cheie din substratul germanic, cum sunt *saiwaz („mare”)1 și *baina- („os”)<sup>1</sup>. În mod tradițional, acești termeni sunt priviți ca anomalies sau împrumuturi non-IE<sup>1</sup>. Cu toate acestea, prin inserarea de laringeale și glotalice, lingviștii forțează alinierea lor la rădăcini PIE:
 • Etimologia pentru *saiwaz: Cuvântul este derivat în mod artificial din rădăcina PIE *sei- („a picura”) sau *sai- („durere”), ignorând contextul ecologic<sup>1</sup>. Prin reconstruirea unei forme cu laringeală de tipul *sh₂ey-u-, se justifică trecerea la vocala lungă *ā și ulterior la *ō în proto-germană, mascând faptul că termenul este un împrumut dintr-o limbă pre-indo-europeană din bazinul Mării Baltice<sup>1</sup>.
 • Etimologia pentru *baina-: Lipsit de cognate clare, acest termen este forțat într-o relație cu rădăcina *staina- („piatră”) sau explicat prin procesul cognitiv de îmbinare fonestetică (phonesthetic blending) cu prefixul corporal /b-/ (existent în breast, bosom, back)<sup>2</sup>. Reconstrucțiile de tipul *bʰeh₂-i-no- folosesc laringeala ca variabilă de compensare pentru a crea o potrivire fonetică artificială<sup>3</sup>.
Dacă aplicăm un algoritm de aliniere fonetică computațională, se poate demonstra din punct de vedere matematic cum utilizarea acestor factori de corecție laringeală și glotalică (fudge factors) prăbușește distanțele de editare între cuvinte complet neînrudite, dovedind ușurința cu care se pot fabrica filiații lingvistice<sup>3</sup>.


Distanțele de editare fără factori de ajustare (Fără P-Hacking):
 Distanța (seaw <-> sei) = 1.20
 Distanța (seaw <-> dheubh) = 4.00
 Distanța (bain <-> stai) = 2.60
 Distanța (bain <-> bher) = 2.40
 Distanța (nuit <-> noctem) = 3.00

Distanțele de editare cu laringeale și glotalice active (Cu P-Hacking):
 Distanța (seaw <-> sei) = 0.90
 Distanța (seaw <-> dheubh) = 3.70
 Distanța (bain <-> stai) = 1.75
 Distanța (bain <-> bher) = 2.10
 Distanța (nuit <-> noctem) = 2.70

Se observă cum distanța dintre *baina- (os) și rădăcina nerelevantă *stai- (piatră) scade de la la doar prin permiterea potrivirilor flexibile bazate pe laringeale<sup>3</sup>. Această reducere artificială a distanței computaționale arată cum modelele teoretice prea permisive pot asocia orice termen cu orice rădăcină PIE, subminând rigoarea științifică a comparativei istorice<sup>22</sup>.
Un contra-model metodologic mult mai robust din punct de vedere științific este reprezentat de identificarea împrumuturilor pe baza anomaliilor fonotactice și a sistemelor de prefixe/sufixe specifice, așa cum este descris în Ipoteza Substratului Agricol a lui Guus Kroonen<sup>12</sup>. Acesta identifică o serie de termeni asociați cu expansiunea agriculturii anatoliene în Europa Centrală (cultura Linear Pottery / LBK), caracterizați prin prezența sufixelor specifice non-indo-europene (cum este alternanța *it- sau *-nth- în greaca veche)12:

Lexem Proto-Germanic
Semnificație
Sufix / Tipar Substrat
Cognate Non-IE în Early Greek
Proveniență Istorică Reconstruită
*arwit-
mazăre
Sufix *-it-
[cite: 12]
erebinthos12
Substrat agricol pre-indo-european continental<sup>12</sup>.
*gait-
capră
Prefix/Sufix alternant12
-
Agricultură neolitică non-IE (LBK)<sup>12</sup>.
*hnut-
nucă
Structură monosilabică non-IE12
-
Resursă forestieră indigenă din Europa de Nord<sup>12</sup>.
Aceste asocieri structurale și morfologice, sprijinite pe tipare recurente și pe contextul arheologic al expansiunii neolitice, oferă o metodologie mult mai sigură decât încercările de reconstrucție pur fonetică bazate pe adăugarea arbitrară de laringeale, reprezentând calea de urmat pentru o lingvistică istorică eliberată de dogmatism<sup>12</sup>.
Concluzii: Limitele Epistemologice ale Comparatismului Pur
Studiul comparativ detaliat al cazurilor românesc, francez, germanic și tunisian demonstrează că limbile standardizate moderne nu sunt descendenți lineari și imaculați ai unor limbi imperiale, ci sisteme profund hibridizate rezultate din interacțiunea complexă dintre populații cu origini genetice și culturale diferite<sup>1</sup>. Prioritizarea dogmatică a lexicului de bază și utilizarea corelațiilor fonetice forțate servesc adesea unor interese politice exterioare științei, mascând procesele de creolizare, pidginizare și shift lingvistic<sup>1</sup>.
Fonetica computațională și analiza tipologică modernă evidențiază necesitatea unei abordări metodologice integrative<sup>1</sup>. Atunci când regulile fonetice devin prea flexibile, ele își pierd valoarea explicativă, putând asocia limbi din familii complet diferite sau validând pseudorelații genealogice<sup>1</sup>. Supraviețuirea deprinderilor fonetice și structurale ale substratului (cum este transformarea în cazul românesc sau conservarea structurilor gramaticale balcanice) arată că limbile se dezvoltă prin asimilarea elementelor externe de prestigiu în interiorul unui sistem de operare indigen extrem de rezistent<sup>1</sup>.
În absența dovezilor scrise atestate epigrafic—care pot valida sau infirma în mod definitiv evoluțiile propuse, așa cum se întâmplă în cazul interacțiunii dintre arabă și berberă în Tunisia—reconstrucțiile bazate exclusiv pe similitudini de sunete rămân exerciții teoretice fragile<sup>1</sup>. Prin urmare, lingvistica istorică a secolului al XXI-lea trebuie să depășească faza speculațiilor fonetice etimologice prin integrarea riguroasă a tipologiei morfosintactice, a datelor arheologice și a paleogenomicii, oferind astfel o perspectivă realistă și nuanțată asupra sintezei dinamice care stă la baza limbilor umane<sup>1</sup>.
Lucrări citate
 1. Politics and Science in Linguistics (1).pdf
 2. Introduction to The Etymological Dictionary of The Romanian Language - Limbaromana.org, https://limbaromana.org/en/introduction-to-the-etymological-dictionary-of-the-romanian-language/
 3. unknown_url
 4. List of reconstructed Dacian words - Wikipedia, https://en.wikipedia.org/wiki/List _of_ reconstructed _Dacian_ words
 5. How much Lithuanian and Romanian languages are mutually intelligible?, https://linguistics.stackexchange.com/questions/6694/how-much-lithuanian-and-romanian-languages-are-mutually-intelligible
 6. Translation of "night" into Modern Gaulish - Glosbe, https://en.glosbe.com/en/mis_gal/night
 7. Cognates and False Friends (Ep. 16) - The Future is Bilingual Podcast, https://thefutureisbilingual.wordpress.com/2021/04/05/cognates-and-false-friends-ep-16/
 8. PHOENICIAN/PUNIC LOANS IN BERBER LANGUAGES AND THEIR THEIR ROLE IN CHRONOLOGY OF BERBER, https://journals.pan.pl/Content/85572/mainfile.pdf
 9. 5 Gaulish in the Late Empire (c. 200–600 ce) - Oxford Academic, https://academic.oup.com/book/55329/chapter/434345566
 10. Classification of Thracian - Grokipedia, https://grokipedia.com/page/Classification _of_ Thracian
 11. Tunisian Arabic - Wikipedia, https://en.wikipedia.org/wiki/Tunisian_Arabic
 12. Tunisian Arabic - Grokipedia, https://grokipedia.com/page/Tunisian_Arabic
 13. Pre-Hilalian Arabic dialects - Grokipedia, https://grokipedia.com/page/Pre-Hilalian _Arabic_ dialects
 14. Berber languages - Wikipedia, https://en.wikipedia.org/wiki/Berber_languages
 15. Arabic substrate etymologies as urban legends - Jabal al-Lughat, http://lughat.blogspot.com/2016/04/arabic-substrate-etymologies-as-urban.html
 16. Berber and not so Berber words in Tunisian Arabic - Jabal al-Lughat, http://lughat.blogspot.com/2017/09/berber-and-not-so-berber-words-in.html
 17. Time – Celtiadur - Omniglot, https://www.omniglot.com/celtiadur/category/words/time/
 18. Is it a coincidence that in many European languages, the word for 'night' is the combination of the letter 'n' and some form resembling the number 'eight'? As in 'night, nacht, nuit, notte, noche...' - Quora, https://www.quora.com/Is-it-a-coincidence-that-in-many-European-languages-the-word-for-night-is-the-combination-of-the-letter-n-and-some-form-resembling-the-number-eight-As-in-night-nacht-nuit-notte-noche
 19. Laryngeal theory - Grokipedia, https://grokipedia.com/page/Laryngeal_theory
 20. Glottalic theory - Wikipedia, https://en.wikipedia.org/wiki/Glottalic_theory
 21. Laryngeal theory - Wikipedia, https://en.wikipedia.org/wiki/Laryngeal_theory
 22. From trilaryngealism to monolaryngealism: returning to Oswald Szemerényi - Academia.edu, https://www.academia.edu/35602539/From _trilaryngealism_ to _monolaryngealism_ returning _to_ Oswald_Szemer%C3%A9nyi
 23. kratylos, http://dge.cchs.csic.es/bib/adr/res209.pdf
 24. Issues in the glottalic theory of Indo-European: The comparative method, typology and naturalness, https://www.tandfonline.com/doi/pdf/10.1080/00437956.1995.11435943
 25. Thornas V. Gamkre\idze ΤΗΕ INDO-EUROPEAN "GLOTTALIC THEORY" AND ΤΗΕ SYSTEM OF ANCIENT GREEK CONSONANTISM Let rne, https://www.eshop.ins-auth.gr/images/companies/1/archive/MEG_PLIRI/MEG_20_12-17.pdf
 26. Proto-Germanic language - Wikipedia, https://en.wikipedia.org/wiki/Proto-Germanic_language


---
